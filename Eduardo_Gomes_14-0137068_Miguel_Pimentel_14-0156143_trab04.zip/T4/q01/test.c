#include <stdio.h>
#include <stdlib.h>

int main(void)
{

	printf("This is only a test\n");

	return 0;
}