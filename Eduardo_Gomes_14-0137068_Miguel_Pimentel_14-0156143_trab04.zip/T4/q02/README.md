Trabalho 4 de Fundamentos de Sistemas Operacionais

Para utilizar o software abra um terminal com ctrl + alt + t  por exemplo,
vá a pasta do arquivo e digite:

make
make run

Se preferir, já está pré definido um teste em run que pode ser alterado da maneira que desejar
Por exemplo:

    ./buscador ./archievesOfTest test 7
    ./buscador ./archievesOfTest test 10
    ./buscador . test 3
    ./buscador . 12 4


