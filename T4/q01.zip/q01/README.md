Trabalho 4 de Fundamentos de Sistemas Operacionais

Para utilizar o software abra um terminal com ctrl + alt + t  por exemplo,
vá a pasta do arquivo e digite:

Para compilar e montar Digite:

make

Para executar:

./q01 <file_name> <YYYYMMDDHHmm>

Ressalta-se que file name, refere-se ao arquivo desejado e a  <YYYYMMDDHHmm> se refere a um uma data e horário da seguinte forma: YYYY representa o ano; MM representa o mês; DD representa o dia ; HH representa a hora; e mm representa os minutos.

Para excluir o executável:

make clean 
